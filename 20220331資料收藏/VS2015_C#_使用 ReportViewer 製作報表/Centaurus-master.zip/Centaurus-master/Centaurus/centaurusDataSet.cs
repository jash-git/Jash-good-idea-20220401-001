﻿namespace Centaurus
{
}
namespace Centaurus
{


    partial class centaurusDataSet
    {
        partial class listarParticipanteEmpresaDataTable
        {
        }
    }
}
