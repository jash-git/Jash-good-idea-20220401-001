﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Centaurus.DTO
{
    public class LoginModelo
    {
        public string usuarioLogin { get; set; }
        public string senhaLogin { get; set; }
    }
}
