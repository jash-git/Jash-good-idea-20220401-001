﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Centaurus.Model
{
    public class MarcaModelo
    {

        public int idMarca { get; set; }
        public string nomeMarca { get; set; }
        public bool ativoMarca { get; set; }
    }
}
