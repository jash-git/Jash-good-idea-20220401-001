﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Centaurus.Model
{
    public class CidadeModelo
    {

        public int idCidade { get; set; }

        public string  nomeCidade { get; set; }

    }
}
