﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Centaurus.Model
{
    public class CategoriaModelo
    {
        public int idCategoria { get; set; }
        public string nomeCategoria { get; set; }
        public bool ativoCategoria { get; set; }
        public char tipoCategoria { get; set; }

    }
}
