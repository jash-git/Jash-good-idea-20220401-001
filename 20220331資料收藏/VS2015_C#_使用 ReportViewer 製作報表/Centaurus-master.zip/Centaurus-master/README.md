# Centaurus
CRUD em C# - Locação de Produtos.
- Cadastro de Produto.
- Cadastro de Marca.
- Cadastro de Categoria e Sub-Categoria.
- Cadastro de Participante.
- Relatório de Participante.
- Cadastro de Usuário.
- Locação e Devolução do Produto. 
